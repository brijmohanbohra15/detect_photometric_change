import os
import matplotlib.pyplot as plt


def plot_and_save_outlier_analysis(
    norad_id,
    df_ref_annotated,
    df_cur_annotated,
    output_path,

):
    """
    Plot and save contextual outlier analysis for a specific NORAD ID.

    Parameters
    ----------
    norad_id : int
    df_ref_annotated : pd.DataFrame
        DataFrame containing data for the reference period
    df_cur_annotated : pd.DataFrame
        DataFrame containing data for the current period
    output_path : str
        Path to save the output plot

    Returns
    -------
    None
        Saves plot to file
    """

    # Skip if both datasets are empty
    if df_ref_annotated is None and df_cur_annotated is None:
        return

    # Create figure with 2 subplots
    fig, axes = plt.subplots(1, 2, figsize=(14, 6), sharey=True)

    # ------------------
    # Reference plot
    # ------------------
    if df_ref_annotated is not None and not df_ref_annotated.empty:
        df_plot = df_ref_annotated.copy()

        df_plot['point_type'] = 'Normal'
        df_plot.loc[df_plot['is_glint'], 'point_type'] = 'Glint'
        df_plot.loc[
            df_plot['is_contextual_outlier'], 'point_type'
        ] = 'Contextual Outlier'

        for label, d in df_plot.groupby('point_type'):
            axes[0].scatter(
                d['equatorial_phase'],
                d['magnitude_filled'],
                label=label,
                s=30,
                alpha=0.7
            )

        axes[0].set_title(f"NORAD {norad_id} – Reference")
        axes[0].set_xlabel("Equatorial Phase (deg)")
        axes[0].set_ylabel("Magnitude")
        axes[0].grid(True)
        axes[0].legend()

    else:
        axes[0].text(
            0.5, 0.5, "No Reference Data",
            ha='center', va='center', transform=axes[0].transAxes
        )
        axes[0].set_axis_off()

    # ------------------
    # Current plot
    # ------------------
    if df_cur_annotated is not None and not df_cur_annotated.empty:
        df_plot = df_cur_annotated.copy()

        df_plot['point_type'] = 'Normal'
        df_plot.loc[df_plot['is_glint'], 'point_type'] = 'Glint'
        df_plot.loc[
            df_plot['is_contextual_outlier'], 'point_type'
        ] = 'Contextual Outlier'

        for label, d in df_plot.groupby('point_type'):
            axes[1].scatter(
                d['equatorial_phase'],
                d['magnitude_filled'],
                label=label,
                s=30,
                alpha=0.7
            )

        axes[1].set_title(f"NORAD {norad_id} – Current")
        axes[1].set_xlabel("Equatorial Phase (deg)")
        axes[1].grid(True)
        axes[1].legend()

    else:
        axes[1].text(
            0.5, 0.5, "No Current Data",
            ha='center', va='center', transform=axes[1].transAxes
        )
        axes[1].set_axis_off()

    plt.suptitle("Contextual Outliers & Glinting Effects", fontsize=14)
    plt.tight_layout()
    outlier_impute_path = os.path.join(output_path, 'outlier_impute')
    # Create output directory if it doesn't exist
    os.makedirs(outlier_impute_path, exist_ok=True)

    # Save plot with filename based on norad_id
    output_file = os.path.join(
        outlier_impute_path, f"norad_{norad_id}_outlier_analysis.png"
    )
    plt.savefig(output_file, dpi=150, bbox_inches='tight')
    plt.close()


def plot_collective_anomalies(
    df_ref,
    df_cur,
    df_collective,
    norad_id,
    output_path,
    phase_bin_width=10
):
    """
    Plot and save collective anomalies for a specific NORAD ID.

    Parameters
    ----------
    df_ref : pd.DataFrame
        DataFrame containing reference period data
    df_cur : pd.DataFrame
        DataFrame containing current period data
    df_collective : pd.DataFrame
        DataFrame containing collective anomaly information
    norad_id : int
        NORAD ID to process
    output_path : str
        Base path to save the output plot
    phase_bin_width : int, default=10
        Width of phase bins

    Returns
    -------
    None
        Saves plot to file in output_path/anomaly_fig directory
    """
    plt.figure(figsize=(11, 7))

    # --- Reference points ---
    plt.scatter(
        df_ref['equatorial_phase'],
        df_ref['magnitude_filled'],
        c='gray',
        alpha=0.4,
        s=25,
        label='Reference'
    )

    # --- Current points ---
    plt.scatter(
        df_cur['equatorial_phase'],
        df_cur['magnitude_filled'],
        c='blue',
        alpha=0.7,
        s=35,
        label='Current'
    )

    # --- Only TRUE collective anomalies ---
    anomaly_bins = df_collective[df_collective['is_collective_anomaly']]

    shown_labels = set()

    for _, row in anomaly_bins.iterrows():
        pb = row['phase_bin']
        atype = row.get('anomaly_type', 'distribution')

        color = 'red' if atype == 'distribution' else 'orange'
        label = f'{atype.capitalize()} anomaly'

        plt.axvspan(
            pb,
            pb + phase_bin_width,
            color=color,
            alpha=0.25,
            label=label if label not in shown_labels else None
        )

        shown_labels.add(label)

    plt.xlabel("Equatorial Phase Angle (deg)")
    plt.ylabel("Magnitude")
    plt.title(f"NORAD {norad_id}: Collective Phase-bin Anomalies")

    plt.legend()
    plt.grid(True)
    plt.tight_layout()

    # Create output directory if it doesn't exist
    anomaly_fig_path = os.path.join(output_path, 'anomaly_fig')
    os.makedirs(anomaly_fig_path, exist_ok=True)

    # Save plot with filename based on norad_id
    output_file = os.path.join(
        anomaly_fig_path, f"norad_{norad_id}_collective_anomalies.png"
    )
    plt.savefig(output_file, dpi=150, bbox_inches='tight')
    plt.close()


def plot_contextual_outliers_no_fill(
    norad_id,
    df_ref_annotated,
    df_cur_annotated,
    output_path=None,
    show_plot=True
):
    """
    Plot contextual outlier analysis for a specific NORAD ID without filling.

    This function displays reference and current period data with point types
    (Normal, Glint, Contextual Outlier) using the original magnitude values
    (not magnitude_filled).

    Parameters
    ----------
    norad_id : int
        NORAD ID to process
    df_ref_annotated : pd.DataFrame or None
        DataFrame containing data for the reference period
    df_cur_annotated : pd.DataFrame or None
        DataFrame containing data for the current period
    output_path : str, optional
        Base path to save the output plot. If None, plot is not saved.
        Plot will be saved in output_path/outlier_detect directory.
    show_plot : bool, default=True
        Whether to display the plot using plt.show()

    Returns
    -------
    None
        Displays or saves plot to file in output_path/outlier_detect directory
    """
    # Skip if both datasets are empty
    if df_ref_annotated is None and df_cur_annotated is None:
        return

    # Create figure with 2 subplots
    fig, axes = plt.subplots(1, 2, figsize=(14, 6), sharey=True)

    # ------------------
    # Reference plot
    # ------------------
    if df_ref_annotated is not None and not df_ref_annotated.empty:
        df_plot = df_ref_annotated.copy()

        df_plot['point_type'] = 'Normal'
        df_plot.loc[df_plot['is_glint'], 'point_type'] = 'Glint'
        df_plot.loc[
            df_plot['is_contextual_outlier'], 'point_type'
        ] = 'Contextual Outlier'

        for label, d in df_plot.groupby('point_type'):
            axes[0].scatter(
                d['equatorial_phase'],
                d['magnitude'],
                label=label,
                s=30,
                alpha=0.7
            )

        axes[0].set_title(f"NORAD {norad_id} – Reference")
        axes[0].set_xlabel("Equatorial Phase (deg)")
        axes[0].set_ylabel("Magnitude")
        axes[0].grid(True)
        axes[0].legend()

    else:
        axes[0].text(
            0.5, 0.5, "No Reference Data",
            ha='center', va='center', transform=axes[0].transAxes
        )
        axes[0].set_axis_off()

    # ------------------
    # Current plot
    # ------------------
    if df_cur_annotated is not None and not df_cur_annotated.empty:
        df_plot = df_cur_annotated.copy()

        df_plot['point_type'] = 'Normal'
        df_plot.loc[df_plot['is_glint'], 'point_type'] = 'Glint'
        df_plot.loc[
            df_plot['is_contextual_outlier'], 'point_type'
        ] = 'Contextual Outlier'

        for label, d in df_plot.groupby('point_type'):
            axes[1].scatter(
                d['equatorial_phase'],
                d['magnitude'],
                label=label,
                s=30,
                alpha=0.7
            )

        axes[1].set_title(f"NORAD {norad_id} – Current")
        axes[1].set_xlabel("Equatorial Phase (deg)")
        axes[1].grid(True)
        axes[1].legend()

    else:
        axes[1].text(
            0.5, 0.5, "No Current Data",
            ha='center', va='center', transform=axes[1].transAxes
        )
        axes[1].set_axis_off()

    plt.suptitle("Contextual Outliers & Glinting Effects", fontsize=14)
    plt.tight_layout()

    # Save plot if output_path is provided
    if output_path is not None:
        # Create output directory with outlier_detect subdirectory
        outlier_detect_path = os.path.join(output_path, 'outlier_detect')
        os.makedirs(outlier_detect_path, exist_ok=True)

        # Save plot with filename based on norad_id
        filename = f"norad_{norad_id}_outlier_analysis_no_fill.png"
        output_file = os.path.join(outlier_detect_path, filename)
        plt.savefig(output_file, dpi=150, bbox_inches='tight')
        plt.close()
    elif show_plot:
        plt.show()
    else:
        plt.close()
