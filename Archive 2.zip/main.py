def main():
    print("Hello from detect-photometric-change!")


if __name__ == "__main__":
    main()
