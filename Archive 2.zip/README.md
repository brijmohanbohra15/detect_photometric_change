# Photometric Change Detection

A tool for detecting photometric anomalies.

## Configuration

Change  `config.json` file which is available in the following structure:

```json
{
  "data": {
    "raw_path": "data/raw/era1",
    "output_path": "data/processed/era1"
  },
  "dates": {
    "Reference_Start": "2025-10-31 03:20:19",
    "Reference_End": "2025-11-07 03:20:19",
    "Current_Start": "2025-11-07 03:20:19",
    "Current_End": "2025-11-07 09:20:19"
  },
  "bin_width": 10
}
```

## How to Run

### Method 1: Command Line (Recommended)

Run the pipeline using the command line:

```bash
python src/main.py 
```

## Output

After running, you will find:

- **Plots**: Saved in `{output_path}/anomaly_fig/norad_{id}_collective_anomalies.png`
- **Anomaly Records**: Saved in `{output_path}/collective_anomalies.json`
